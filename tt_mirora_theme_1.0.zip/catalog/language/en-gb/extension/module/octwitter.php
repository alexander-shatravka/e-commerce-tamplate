<?php
// Heading
$_['heading_title']    = 'LATEST TWEETS';