<?php
// Text
$_['button_read_more']         		 = 'Read more';
$_['text_blog_empty']           			 = 'No articles';
$_['text_post_by']           			 = 'post by: ';
$_['text_headingtitle']           			 = 'From Our Blog';
$_['text_blog'] = 'Blog';
$_['sub_title'] = 'Our blog';
